import { ModalBuilder, ActionRowBuilder, TextInputBuilder, TextInputStyle } from 'discord.js';

const ticketTypes = {
  player_report: { label: 'إبلاغ عن لاعب', modalTitle: 'إبلاغ عن لاعب' },
  technical_support: { label: 'دعم فني وأخطاء', modalTitle: 'دعم فني وأخطاء' },
  general_question: { label: 'استفسار عام أو سؤال', modalTitle: 'استفسار عام' },
  false_ban: { label: 'بان حماية بالخطأ', modalTitle: 'مراجعة حظر الحماية' },
  store_support: { label: 'المتجر', modalTitle: 'دعم المتجر' },
};

export default {
  name: 'ticket_create_select',
  async execute(interaction) {
    const type = interaction.values?.[0];
    const selected = ticketTypes[type];
    if (!selected) {
      await interaction.reply({ content: 'نوع التذكرة غير صالح. حاول مرة أخرى.', ephemeral: true });
      return;
    }
    const modal = new ModalBuilder()
      .setCustomId(`create_ticket_modal:${type}`)
      .setTitle(selected.modalTitle);
    const reason = new TextInputBuilder()
      .setCustomId('reason')
      .setLabel('اكتب تفاصيل طلبك')
      .setStyle(TextInputStyle.Paragraph)
      .setPlaceholder(`اشرح تفاصيل: ${selected.label}`)
      .setRequired(true)
      .setMaxLength(1000);
    modal.addComponents(new ActionRowBuilder().addComponents(reason));
    await interaction.showModal(modal);
  },
};
